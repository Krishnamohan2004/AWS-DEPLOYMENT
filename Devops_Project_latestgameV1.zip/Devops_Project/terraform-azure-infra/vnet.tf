resource "azurerm_virtual_network" "deploy_vnet" {

  name                = var.vnet_name
  location            = azurerm_resource_group.deploy_rg.location
  resource_group_name = azurerm_resource_group.deploy_rg.name
  address_space       = var.vnet_address_space

  depends_on = [
    azurerm_resource_group.deploy_rg
  ]

}