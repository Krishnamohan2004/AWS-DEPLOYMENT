resource "azurerm_kubernetes_cluster" "aks" {

  name                = var.aks_name
  location            = azurerm_resource_group.deploy_rg.location
  resource_group_name = azurerm_resource_group.deploy_rg.name
  dns_prefix          = "boardaks"

  default_node_pool {

    name       = "default"
    node_count = var.node_count
    vm_size    = var.vm_size

    vnet_subnet_id = azurerm_subnet.deploy_subnet.id

  }

  identity {
    type = "SystemAssigned"
  }

  depends_on = [
    azurerm_subnet.deploy_subnet,
    azurerm_container_registry.acr
  ]

}