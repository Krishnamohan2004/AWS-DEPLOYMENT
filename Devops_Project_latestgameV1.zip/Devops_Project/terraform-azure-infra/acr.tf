resource "azurerm_container_registry" "acr" {

  name                = var.acr_name
  location            = azurerm_resource_group.deploy_rg.location
  resource_group_name = azurerm_resource_group.deploy_rg.name

  sku           = "Basic"
  admin_enabled = true

  depends_on = [
    azurerm_resource_group.deploy_rg
  ]

}