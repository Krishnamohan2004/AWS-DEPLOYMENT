provider "azurerm" {
  features {}
}

 
