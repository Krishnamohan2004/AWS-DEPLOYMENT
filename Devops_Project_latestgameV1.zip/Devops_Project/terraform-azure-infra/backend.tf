terraform {

  backend "azurerm" {

    resource_group_name  = "Agent_RG"
    storage_account_name = "vcubedevopsstoragenew"
    container_name       = "tfstate"
    key                  = "devops-project.tfstate"

  }

}