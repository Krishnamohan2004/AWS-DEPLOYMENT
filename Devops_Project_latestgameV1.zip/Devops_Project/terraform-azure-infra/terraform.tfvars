location = "centralindia"

resource_group_name = "Deployment_RG"

vnet_name = "deployment-vnet"
vnet_address_space = ["10.2.0.0/16"]

subnet_name = "deployment-subnet"
subnet_prefix = ["10.2.1.0/24"]

acr_name = "vcubedevopsacr001"

aks_name = "vcubeakscluster"

node_count = 1

vm_size = "Standard_B2s"