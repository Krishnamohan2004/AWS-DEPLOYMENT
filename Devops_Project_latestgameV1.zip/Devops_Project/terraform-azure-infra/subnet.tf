resource "azurerm_subnet" "deploy_subnet" {

  name                 = var.subnet_name
  resource_group_name  = azurerm_resource_group.deploy_rg.name
  virtual_network_name = azurerm_virtual_network.deploy_vnet.name
  address_prefixes     = var.subnet_prefix

  depends_on = [
    azurerm_virtual_network.deploy_vnet
  ]

}